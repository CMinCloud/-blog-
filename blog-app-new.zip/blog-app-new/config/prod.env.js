'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://47.113.193.238/api/"'
}
